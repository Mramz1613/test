# all_files =[]
# while True:
#     file_name = input("Введите имя файла")
#     if file_name == "quit":
#         break
#     all_files.append(file_name)
#
#
#
#     with open("resalt.txt","w",encoding="utf-8") as res:
#         for file in all_files:
#             with open(file,"r",encoding="utf-8") as cur_file:
#                 res.writelines(cur_file.readlines())


all_files =[]
while True:
    file_name = input("Введите имя файла")
    if file_name == "quit":
        break
    all_files.append(file_name)


    common_set = set()
    with open("resalt2.txt","w+",encoding="utf-8") as res:
        for file in all_files:
            with open(file,"r",encoding="utf-8") as cur_file:
                common_set = set(cur_file.read())
                for i in cur_file.read():
                    common_set.intersection_update(i)
                print(common_set)
                res.write("".join(common_set))
